package catalogue;

import java.io.Serializable;
import java.util.Collections;//needed for collections.sort


/**
 * The class BetterBasket aims to improve the user experience surrounding each instance of a basket:
 * 	- The basket items are sorted into ascending order, on their product key
 * 	- Multiple items of the same type are grouped into one request for a plural of the same product, rather than listed individually
 * 
 * @Rehman Shabab
 * @version 2.2
 */
public class BetterBasket extends Basket implements Serializable
{
  private static final long serialVersionUID = 1L;

  @Override
  public boolean add (Product pr)
  {
	  //This will group items and if the item is already then will exit and will add method.
	  for (int i=0; i<this.size(); i++){
		  if(this.get(i).getProductNum().equals(pr.getProductNum())){
			  this.get(i).setQuantity(this.get(i).getQuantity() + pr.getQuantity());
			  return true;
		  }
	  }
	  
	  super.add(pr);
	  //Sort
	  Collections.sort(this, BetterBasket::Sort);
	  //betterbasket implies class, sort implies method
	  return true;
	  
  }	 
 
  //called by Collections.sort. and Passes two parameters which is product i and product j,
  public static int Sort (Product i, Product j) { 
	  return i.getProductNum().compareTo(j.getProductNum()); 
  }
  
  //Better method for removing items
  @Override
  public boolean remove (Product pr)
  {
	  //check all items in the basket (i) to see if one matches the product code to remove
	  for (int i=0; i<this.size(); i++){
		  if(this.get(i).getProductNum().equals(pr.getProductNum())){ //if a match is found:
			  //Reduce 1 from the product quantity
			  this.get(i).setQuantity(this.get(i).getQuantity() - pr.getQuantity());
			  //check removed completely from list 0 or less quantity
			  if (this.get(i).getQuantity() <= 0){
				  super.remove(i);
			  }  
			  return true; //exit method
		  } 	  
	  }
	    
	  return false;
  }
  
  //Check item in the basket
  @Override
  public boolean checkList(Product pr)
  {
	  for (int i =0; i<this.size(); i++){
		  if(this.get(i).getProductNum().equals(pr.getProductNum())){
			  return true;
			  }
	  } 
	  return false;
  }
  
  
}
	  
  

